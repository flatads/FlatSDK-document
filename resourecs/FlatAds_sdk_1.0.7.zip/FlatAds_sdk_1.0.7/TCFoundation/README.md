# TCFoundation

[![CI Status](https://img.shields.io/travis/flatads/TCFoundation.svg?style=flat)](https://travis-ci.org/flatads/TCFoundation)
[![Version](https://img.shields.io/cocoapods/v/TCFoundation.svg?style=flat)](https://cocoapods.org/pods/TCFoundation)
[![License](https://img.shields.io/cocoapods/l/TCFoundation.svg?style=flat)](https://cocoapods.org/pods/TCFoundation)
[![Platform](https://img.shields.io/cocoapods/p/TCFoundation.svg?style=flat)](https://cocoapods.org/pods/TCFoundation)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TCFoundation is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TCFoundation'
```

## Author

flatads, chenwh02@flatincbr.com

## License

TCFoundation is available under the MIT license. See the LICENSE file for more info.
