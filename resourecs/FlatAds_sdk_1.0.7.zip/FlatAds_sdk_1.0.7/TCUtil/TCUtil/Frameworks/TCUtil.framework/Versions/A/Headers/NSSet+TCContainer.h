//
//  NSSet+TCContainer.h
//  TCUtil
//
//  Created by EkoHu on 2021/3/15.
//

#import <Foundation/Foundation.h>
#import "TCContainerProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface NSSet (TCContainer)<TCContainerDeepCopyProtocol>

@end

NS_ASSUME_NONNULL_END
